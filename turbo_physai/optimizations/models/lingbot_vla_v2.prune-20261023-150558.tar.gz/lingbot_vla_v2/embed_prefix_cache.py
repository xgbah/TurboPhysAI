# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause
#
# Modified by Hygon: cache the deepstack gather in ``FlowMatchingV2.embed_prefix``
# and hoist it out of the loop, so Dynamo stops dropping the enclosing frame.
# Also turns the ``flat_grid_thw[flat_img_masks]`` boolean gather into a cached
# ``index_select`` so the RoPE grid selection stays traceable too.
#
# Wrapped symbol and its TurboPhysAI replacement:
#   lingbotvla.models.vla.lingbot_vla.modeling_lingbot_vla_v2.
#   FlowMatchingV2.embed_prefix
#       -> this module's wrap_embed_prefix
#
# Declared by the Group ``lingbot-vla-v2.embed-prefix-cache`` in catalog.py.
"""Make ``FlowMatchingV2.embed_prefix`` stop forcing a frame skip.

Two separate boolean-indexing sites are rewritten; each one is patched
independently, so a drift in one does not disable the other.

Site 1 -- the deepstack gather (upstream ``modeling_lingbot_vla_v2.py`` ~line 726)::

    filtered_deepstack = []
    img_visual_only = einops.repeat(img_masks, "b n -> b n l", l=num_patch)
    for deepstack in deepstack_embs:
        filtered_deepstack.append(deepstack[img_visual_only])

Site 2 -- the RoPE grid selection (~line 716)::

    flat_img_masks = einops.rearrange(img_masks, "b n -> (b n)")
    rope_grid_thw = flat_grid_thw[flat_img_masks]
    if rope_grid_thw.numel() == 0:
        rope_grid_thw = flat_grid_thw[:1]

Why both break the graph
------------------------
``img_visual_only`` / ``flat_img_masks`` are bool masks, so these are advanced
boolean indexing: PyTorch lowers them to ``aten.index`` + ``aten.nonzero`` whose
output length is ``mask.sum()``.  That value only exists on the device, so
Dynamo cannot infer the output shape and breaks.  For site 1 the indexing also
sits *inside* a ``for`` loop, and ``maybe_has_backedge()`` promotes the break to
a full ``SkipFrame``::

    Skipping frame because there is a graph break in a for/while loop
    torch.compile intentionally decided to skip the frame
      torch_dynamo_resume_in_embed_prefix_at_720 (... line 720) and fall back to eager.

For site 2 the break is compounded: the resulting ``numel()`` is an *unbacked*
SymInt and feeding it to ``if`` raises ``GuardOnDataDependentSymInt``.

What the replacement does
-------------------------
1. **Cache the index.**  ``img_masks`` is a padding mask: it only changes when
   the batch composition changes, so ``mask.nonzero(...)`` is computed once per
   distinct mask and reused.  The lookup is wrapped in
   ``torch._dynamo.disable`` so it never enters the graph.
2. **Hoist it out of the loop.**  The cached index is materialised *before* the
   ``for``, so the only graph break left is outside the loop and Dynamo can
   resume instead of skipping the frame.  Inside the loop the gather is plain
   integer advanced indexing with a constant-length index tensor, whose output
   shape is static and therefore traceable.
3. **Move the emptiness branch to Python.**  For site 2 the cached index also
   carries a python ``bool`` telling whether the mask selected nothing, so the
   ``numel() == 0`` test never touches an unbacked SymInt.

Numerics are untouched: ``tensor[mask]`` and ``tensor[idx0, idx1, idx2]`` (or
``tensor.index_select(0, mask.nonzero().flatten())``) with ``idx =
mask.nonzero(...)`` select the same elements in the same order (``nonzero`` is
row-major), so the result is bit-identical.

The patch rewrites the *source text* of the original method at import time
instead of shipping a copy of it.  If the upstream text ever changes and a
region cannot be located, that region keeps its stock form, and if neither
region can be located the patch silently returns the original function, so a
version drift degrades to "no speedup" rather than to "wrong results".
"""

from __future__ import annotations

import functools
import inspect
import re
import textwrap

import torch

# mask configuration -> {"deepstack": tuple, "thw": tensor}; bounded so a
# pathological training run cannot grow it forever.
_INDEX_CACHE: dict = {}
_INDEX_CACHE_LIMIT = 16


@torch._dynamo.disable
def _entry_key(mask_src: torch.Tensor):
    """Build a hashable key describing one mask configuration.

    Keyed on ``img_masks`` (shape ``[batch, num_images]``) rather than on the
    broadcast masks derived from it: ``img_visual_only`` is ``[b, n, num_patch]``
    and copying tens of thousands of bools to the host every step would cost
    more than the ``nonzero`` it saves.  Every derived mask is a pure function
    of ``img_masks``, so the source is a sufficient key.
    """
    return (
        tuple(mask_src.shape),
        tuple(mask_src.detach().to("cpu", non_blocking=False).flatten().tolist()),
        str(mask_src.device),
    )


@torch._dynamo.disable
def _cache_entry(mask_src: torch.Tensor) -> dict:
    """Return the mutable cache entry for this mask configuration."""
    key = _entry_key(mask_src)
    entry = _INDEX_CACHE.get(key)
    if entry is None:
        if len(_INDEX_CACHE) >= _INDEX_CACHE_LIMIT:
            _INDEX_CACHE.clear()
        entry = {}
        _INDEX_CACHE[key] = entry
    return entry


@torch._dynamo.disable
def deepstack_index(mask: torch.Tensor, mask_src: torch.Tensor):
    """Return ``mask.nonzero(as_tuple=True)``, cached per mask configuration.

    Called once per ``embed_prefix``, outside the deepstack loop.  The result is
    an ordinary tuple of index tensors, so Dynamo treats it as constants with
    known shapes.
    """
    entry = _cache_entry(mask_src)
    hit = entry.get("deepstack")
    if hit is None:
        hit = tuple(t.to(mask.device) for t in mask.nonzero(as_tuple=True))
        entry["deepstack"] = hit
    return hit


def deepstack_take(tensor: torch.Tensor, index) -> torch.Tensor:
    """``tensor[mask]`` expressed with a precomputed integer index tuple."""
    return tensor[index[0], index[1], index[2]]


@torch._dynamo.disable
def thw_index(mask: torch.Tensor, mask_src: torch.Tensor):
    """Return ``(index, is_empty)`` for ``flat_grid_thw[flat_img_masks]``.

    ``index`` is the 1-D ``[count]`` int tensor produced by ``nonzero`` (so
    ``flat_grid_thw.index_select(0, index)`` equals the boolean gather), and
    ``is_empty`` is a plain python bool so the emptiness fallback can be decided
    without branching on an unbacked SymInt.  Both are cached per mask
    configuration.
    """
    entry = _cache_entry(mask_src)
    hit = entry.get("thw")
    if hit is None:
        index = mask.nonzero(as_tuple=False).flatten().to(mask.device)
        hit = (index, bool(index.numel() == 0))
        entry["thw"] = hit
    return hit


# ``for deepstack in deepstack_embs:\n    filtered_deepstack.append(deepstack[img_visual_only])``
_LOOP_RE = re.compile(
    r"(?P<ind>[ \t]*)for[ \t]+deepstack[ \t]+in[ \t]+deepstack_embs[ \t]*:[ \t]*\r?\n"
    r"(?P=ind)[ \t]+filtered_deepstack\.append\(deepstack\[img_visual_only\]\)"
    r"[ \t]*(?:\r?\n)?"
)

# ``flat_img_masks = ...`` / ``rope_grid_thw = flat_grid_thw[flat_img_masks]`` /
# ``if rope_grid_thw.numel() == 0:`` / ``rope_grid_thw = flat_grid_thw[:1]``
_THW_RE = re.compile(
    r"(?P<ind>[ \t]*)flat_img_masks[ \t]*=[ \t]*einops\.rearrange\("
    r"[ \t]*img_masks[ \t]*,[ \t]*(?P<q>['\"])b n -> \(b n\)(?P=q)[ \t]*\)"
    r"[ \t]*\r?\n"
    r"(?P=ind)rope_grid_thw[ \t]*=[ \t]*flat_grid_thw\[[ \t]*flat_img_masks[ \t]*\]"
    r"[ \t]*\r?\n"
    r"(?P=ind)if[ \t]+rope_grid_thw\.numel\(\)[ \t]*==[ \t]*0[ \t]*:[ \t]*\r?\n"
    r"(?P=ind)[ \t]+rope_grid_thw[ \t]*=[ \t]*flat_grid_thw\[[ \t]*:[ \t]*1[ \t]*\]"
    r"[ \t]*(?:\r?\n)?"
)


def _repl_loop(m: re.Match) -> str:
    ind = m.group("ind")
    return (
        f"{ind}_tpai_ds_idx = _tpai_deepstack_index(img_visual_only, img_masks)\n"
        f"{ind}for deepstack in deepstack_embs:\n"
        f"{ind}    filtered_deepstack.append(_tpai_deepstack_take(deepstack, _tpai_ds_idx))\n"
    )


def _repl_thw(m: re.Match) -> str:
    ind = m.group("ind")
    return (
        f'{ind}flat_img_masks = einops.rearrange(img_masks, "b n -> (b n)")\n'
        f"{ind}_tpai_thw_idx, _tpai_thw_empty = _tpai_thw_index(flat_img_masks, img_masks)\n"
        f"{ind}if _tpai_thw_empty:\n"
        f"{ind}    rope_grid_thw = flat_grid_thw[:1]\n"
        f"{ind}else:\n"
        f"{ind}    rope_grid_thw = flat_grid_thw.index_select(0, _tpai_thw_idx)\n"
    )


def _rewrite_source(src: str) -> tuple[str | None, tuple[str, ...]]:
    """Apply every site that can be located.  Independent per site."""
    applied: list[str] = []
    new, n = _LOOP_RE.subn(_repl_loop, src)
    if n:
        applied.append("deepstack")
    new, n = _THW_RE.subn(_repl_thw, new)
    if n:
        applied.append("thw")
    if not applied:
        return None, ()
    return new, tuple(applied)


def _build_patched(original):
    """Rewrite the original method's source; return ``None`` if it drifted."""
    try:
        src = textwrap.dedent(inspect.getsource(original))
        new_src, applied = _rewrite_source(src)
        if new_src is None:
            return None
        glb = dict(original.__globals__)
        glb["_tpai_deepstack_index"] = deepstack_index
        glb["_tpai_deepstack_take"] = deepstack_take
        glb["_tpai_thw_index"] = thw_index
        exec(compile(new_src, original.__code__.co_filename, "exec"), glb)
        fn = glb[original.__name__]
        fn.__tpai_applied__ = applied  # introspection aid for debugging
        return fn
    except Exception:
        return None


def wrap_embed_prefix(original, options=None):
    """Return a drop-in ``embed_prefix`` with the cached, hoisted gathers."""
    patched = _build_patched(original)
    if patched is None:
        # Upstream text changed: keep the stock behaviour rather than risk a
        # silent mismatch.
        return original

    @functools.wraps(original)
    def wrapper(self, *args, **kwargs):
        return patched(self, *args, **kwargs)

    wrapper.__wrapped_patched__ = patched  # introspection aid for debugging
    wrapper.__tpai_applied__ = patched.__tpai_applied__
    return wrapper
