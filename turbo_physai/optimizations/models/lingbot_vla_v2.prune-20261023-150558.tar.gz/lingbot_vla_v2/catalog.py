# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause

"""lingbot_vla_v2 optimization declarations.

Add model-specific Groups here. Importing this module registers the declarations
with TurboPhysAI; the generated OptimizationConfig loads it through optimization_modules.

Declarations only describe target/replacement pairs as strings; nothing here imports
lingbotvla and nothing resolves runtime objects at import time.

The package directory name must stay a valid Python identifier (``lingbot_vla_v2``),
because ``optimization_modules`` and every ``replacement`` path is imported through
``importlib``.  ``--model`` also normalizes ``-`` to ``_``, so a directory named
``lingbot_vla_v2`` is reachable as both ``--model lingbot-vla-v2`` and
``--model lingbot_vla_v2``, while a hyphenated directory name would be unreachable.
"""

from __future__ import annotations

from ....engine.definitions import group, replace, wrap

# --- Profiling: torch profiler setup -----------------------------------------
PROFILER = group(
    "lingbot-vla-v2.profiling",
    replace(
        target="lingbotvla.utils.helper.create_profiler",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.profiling.create_profiler"
        ),
    ),
)

# --- Muon optimizer: DTensor-aware Newton-Schulz orthogonalization -------------
MUON = group(
    "lingbot-vla-v2.muon",
    replace(
        target="lingbotvla.optim.muon.DistributedMuon",
        aliases=("lingbotvla.optim.optimizer.DistributedMuon",),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.muon.DistributedMuon"
        ),
    ),
    replace(
        target="lingbotvla.optim.muon.split_muon_adamw_params",
        aliases=("lingbotvla.optim.optimizer.split_muon_adamw_params",),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.muon.split_muon_adamw_params"
        ),
    ),
    replace(
        target="lingbotvla.optim.muon.batched_newton_schulz",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.muon.batched_newton_schulz"
        ),
    ),
)

# --- Attention: tuned flex-attention kernel-option table ----------------------
FLEX_KERNEL_OPTIONS = group(
    "lingbot-vla-v2.flex-kernel-options",
    wrap(
        target="lingbotvla.models.vla.lingbot_vla.flex_attention.flex_attention",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.flex_kernel_options."
            "flex_attention_kernel_options"
        ),
    ),
)

# --- Vision tower: patch embedding as a GEMM instead of a Conv3d --------------
VISION_PATCH_EMBED = group(
    "lingbot-vla-v2.vision-patch-embed",
    replace(
        target=(
            "transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLVisionPatchEmbed."
            "forward"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.vision_patch_embed."
            "forward"
        ),
    ),
)

# --- Vision tower: precompute_grid_thw cache + optional per-block compile -----
VISION_PRECOMPUTE = group(
    "lingbot-vla-v2.vision-precompute",
    # ``wrap`` instead of ``replace`` so the Group's options reach the
    # implementation: ``compile_blocks`` switches on the per-layer
    # ``torch.compile`` path, and ``compile`` is forwarded to ``torch.compile``.
    wrap(
        target=(
            "lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla."
            "forward_without_grid_thw"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.vision_precompute."
            "compile_vision_blocks"
        ),
    ),
    replace(
        target=(
            "lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla."
            "Qwen3VLVisionModel.fast_pos_embed_interpolate"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.vision_precompute."
            "fast_pos_embed_interpolate"
        ),
    ),
)

# --- Teachers: compile the frozen distillation forwards ----------------------
TEACHER_COMPILE = group(
    "lingbot-vla-v2.teacher-compile",
    wrap(
        target="lingbotvla.models.vla.vision_models.module_utils.v2.forward",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2."
            "teacher_forward_compile.compiled_forward"
        ),
    ),
    wrap(
        target=(
            "lingbotvla.models.vla.vision_models.module_utils."
            "v2_morgbd.forward_feat"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2."
            "teacher_forward_compile.compiled_forward"
        ),
    ),
    # Video / DINOv3 teacher: ``DinoVideoTeacher.get_future_feature`` ->
    # ``self.adapter.get_intermediate_layers``.  Without this entry the whole
    # DINOv3 backbone runs one ATen kernel at a time (profiled as
    # ``layers/block.py:309 forward`` in python_function, never inside a
    # ``Torch-Compiled Region``).
    wrap(
        target=(
            "lingbotvla.models.vla.vision_models.dino_video.lumos_dinov3."
            "models.inference.CausalEvalAdapter.get_intermediate_layers"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2."
            "teacher_forward_compile.compiled_forward"
        ),
    ),
)

# --- keep the dead ``self.steps`` counter out of the guards -----------
DYNAMO_SAFE_STEPS = group(
    "lingbot-vla-v2.disable-step-counter",
    wrap(
        target=(
            "lingbotvla.models.vla.lingbot_vla.modeling_lingbot_vla_v2."
            "FlowMatchingV2.__init__"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.disable_step_counter.wrap_init"
        ),
    ),
)

# --- Prefix embedding: cache the deepstack gather -----------------------------
# Hoists ``mask.nonzero()`` out of the deepstack loop so Dynamo stops skipping
# the whole ``embed_prefix`` frame ("graph break in a for/while loop").
EMBED_PREFIX_CACHE = group(
    "lingbot-vla-v2.embed-prefix-cache",
    wrap(
        target=(
            "lingbotvla.models.vla.lingbot_vla.modeling_lingbot_vla_v2."
            "FlowMatchingV2.embed_prefix"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.embed_prefix_cache."
            "wrap_embed_prefix"
        ),
    ),
)

# --- Dynamo: shape-stable deepstack scatter ----------------------------------
DEEPSTACK_FIXED_SHAPE = group(
    "lingbot-vla-v2.deepstack-fixed-shape",
    replace(
        target=(
            "transformers.models.qwen3_vl.modeling_qwen3_vl."
            "Qwen3VLTextModel._deepstack_process"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2."
            "deepstack_fixed_shape._deepstack_process"
        ),
    ),
)
