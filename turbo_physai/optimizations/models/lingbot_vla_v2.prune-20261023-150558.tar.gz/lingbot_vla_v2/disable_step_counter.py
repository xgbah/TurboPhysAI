# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import functools

import torch


class DisabledStepCounter:
    """Monotonic counter whose in-place add stays out of the traced graph.

    Replaces the plain ``int`` so Dynamo has no value to specialise on.  The
    value itself is preserved, in case a downstream consumer is ever added back.
    """

    def __init__(self, value: int = 0) -> None:
        self.value = int(value)

    @torch._dynamo.disable
    def __iadd__(self, other):
        self.value += int(other)
        return self

    def __int__(self) -> int:
        return self.value

    def __index__(self) -> int:
        return self.value

    def __repr__(self) -> str:
        return f"DisabledStepCounter({self.value})"


def wrap_init(original, options=None):
    """Return an ``__init__`` wrapper that installs :class:`DisabledStepCounter`.

    ``FlowMatchingV2.__init__`` assigns ``self.steps = 0`` (only when
    ``align_params`` is non-empty); the wrapper swaps that ``int`` for the
    Dynamo-safe object right after the constructor returns.
    """

    @functools.wraps(original)
    def wrapped(self, *args, **kwargs):
        original(self, *args, **kwargs)
        steps = self.__dict__.get("steps", None)
        if isinstance(steps, int):
            self.__dict__["steps"] = DisabledStepCounter(steps)
        return None

    return wrapped
