# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import functools
from typing import Optional

import torch


def _compile_block_forward(blk, compile_options):
    """Compile one block's ``forward`` and let ``__call__`` reach it.

    The checkpoint wrapper lives in ``GradientCheckpointingLayer.__call__``
    (``self._gradient_checkpointing_func(partial(super().__call__, **kwargs), *args)``),
    i.e. *outside* the block computation.  Compiling the block object would put
    ``torch.compile`` outside the checkpoint, where Dynamo breaks on the
    checkpoint HOP and the recomputed forward stays eager.  Instead we compile
    ``blk.forward`` and shadow the bound method on the instance, so the
    existing ``__call__`` keeps its checkpoint branch, FSDP hooks and kwargs
    handling, and the checkpoint recomputes a compiled graph.

    The compiled callable is cached on the instance; shadowing ``forward`` is
    idempotent across steps.
    """
    cached = getattr(blk, "_tp_compiled_forward", None)
    if cached is None:
        cached = torch.compile(blk.forward, **compile_options)
        blk._tp_compiled_forward = cached
        blk.forward = cached
    return cached


def compile_vision_blocks(original, options=None):
    """Group entry point: per-layer ``torch.compile`` for the vision blocks.

    ``options["compile_blocks"]`` enables the path; ``options["compile"]`` is
    forwarded verbatim to ``torch.compile`` (e.g. ``{"dynamic": True}``).
    When the switch is off the original forward is returned untouched.
    """
    options = dict(options or {})
    if not options.get("compile_blocks", False):
        return original

    compile_options = dict(options.get("compile") or {})

    @functools.wraps(original)
    def wrapped(
        self,
        hidden_states: torch.Tensor,
        grid_thw: torch.Tensor = None,
        pos_embeds: Optional[torch.Tensor] = None,
        position_embeddings: Optional[tuple[torch.Tensor, torch.Tensor]] = None,
        cu_seqlens: Optional[torch.Tensor] = None,
        max_seqlen: Optional[int] = None,
        **kwargs,
    ) -> torch.Tensor:
        hidden_states = self.patch_embed(hidden_states)

        if position_embeddings is None or cu_seqlens is None or max_seqlen is None:
            _, position_embeddings, cu_seqlens, _, max_seqlen = self.preprcess_grid_thw(grid_thw)
        if pos_embeds is None:
            pos_embeds = self.fast_pos_embed_interpolate(grid_thw)

        hidden_states = hidden_states + pos_embeds
        seq_len, _ = hidden_states.size()
        hidden_states = hidden_states.reshape(seq_len, -1)

        deepstack_feature_lists = []
        for layer_num, blk in enumerate(self.blocks):
            _compile_block_forward(blk, compile_options)
            hidden_states = blk(
                hidden_states,
                cu_seqlens=cu_seqlens,
                position_embeddings=position_embeddings,
                max_seqlen=max_seqlen,
                **kwargs,
            )
            if layer_num in self.deepstack_visual_indexes:
                deepstack_feature = self.deepstack_merger_list[
                    self.deepstack_visual_indexes.index(layer_num)
                ](hidden_states)
                deepstack_feature_lists.append(deepstack_feature)

        hidden_states = self.merger(hidden_states)
        return hidden_states, deepstack_feature_lists

    return wrapped


def forward_without_grid_thw(
    self,
    hidden_states: torch.Tensor,
    grid_thw: torch.Tensor = None,
    pos_embeds: Optional[torch.Tensor] = None,
    position_embeddings: Optional[tuple[torch.Tensor, torch.Tensor]] = None,
    cu_seqlens: Optional[torch.Tensor] = None,
    max_seqlen: Optional[int] = None,
    **kwargs,
) -> torch.Tensor:
    hidden_states = self.patch_embed(hidden_states)

    if position_embeddings is None or cu_seqlens is None or max_seqlen is None:
        _, position_embeddings, cu_seqlens, _, max_seqlen = self.preprcess_grid_thw(grid_thw)
    if pos_embeds is None:
        pos_embeds = self.fast_pos_embed_interpolate(grid_thw)

    hidden_states = hidden_states + pos_embeds
    seq_len, _ = hidden_states.size()
    hidden_states = hidden_states.reshape(seq_len, -1)

    deepstack_feature_lists = []
    for layer_num, blk in enumerate(self.blocks):
        hidden_states = blk(
            hidden_states,
            cu_seqlens=cu_seqlens,
            position_embeddings=position_embeddings,
            max_seqlen=max_seqlen,
            **kwargs,
        )
        if layer_num in self.deepstack_visual_indexes:
            deepstack_feature = self.deepstack_merger_list[self.deepstack_visual_indexes.index(layer_num)](
                hidden_states
            )
            deepstack_feature_lists.append(deepstack_feature)

    hidden_states = self.merger(hidden_states)
    return hidden_states, deepstack_feature_lists


# ---------------------------------------------------------------------------
# fast_pos_embed_interpolate: cache the parameter-independent index tables
# ---------------------------------------------------------------------------
_POS_EMBED_CACHE: dict = {}
_POS_EMBED_CACHE_LIMIT = 16


def _build_pos_embed_tables(self, grid_thw: torch.Tensor, dtype: torch.dtype):
    """Build the position-embedding index/weight tables on the CPU.

    Mirrors ``Qwen3VLVisionModel.fast_pos_embed_interpolate`` up to (but not
    including) the ``self.pos_embed`` lookup.  ``grid_thw`` is converted to
    Python ints once, which is what removes the data-dependent scalars.
    """
    rows = grid_thw.detach().to("cpu").tolist()
    num_grid_per_side = self.num_grid_per_side
    merge_size = self.config.spatial_merge_size

    idx_list = [[] for _ in range(4)]
    weight_list = [[] for _ in range(4)]

    for _t, h, w in rows:
        h_idxs = torch.linspace(0, num_grid_per_side - 1, h)
        w_idxs = torch.linspace(0, num_grid_per_side - 1, w)

        h_idxs_floor = h_idxs.int()
        w_idxs_floor = w_idxs.int()
        h_idxs_ceil = (h_idxs.int() + 1).clip(max=num_grid_per_side - 1)
        w_idxs_ceil = (w_idxs.int() + 1).clip(max=num_grid_per_side - 1)

        dh = h_idxs - h_idxs_floor
        dw = w_idxs - w_idxs_floor

        base_h = h_idxs_floor * num_grid_per_side
        base_h_ceil = h_idxs_ceil * num_grid_per_side

        indices = [
            (base_h[None].T + w_idxs_floor[None]).flatten(),
            (base_h[None].T + w_idxs_ceil[None]).flatten(),
            (base_h_ceil[None].T + w_idxs_floor[None]).flatten(),
            (base_h_ceil[None].T + w_idxs_ceil[None]).flatten(),
        ]

        weights = [
            ((1 - dh)[None].T * (1 - dw)[None]).flatten(),
            ((1 - dh)[None].T * dw[None]).flatten(),
            (dh[None].T * (1 - dw)[None]).flatten(),
            (dh[None].T * dw[None]).flatten(),
        ]

        for i in range(4):
            idx_list[i].extend(indices[i].tolist())
            weight_list[i].extend(weights[i].tolist())

    idx_tensor = torch.tensor(idx_list, dtype=torch.long)
    # Built in the target dtype straight from the Python floats, matching the
    # original ``torch.tensor(weight_list, dtype=self.pos_embed.weight.dtype)``.
    weight_tensor = torch.tensor(weight_list, dtype=dtype)

    split_sizes = [int(h) * int(w) for _t, h, w in rows]
    shapes = [
        (int(t), int(h) // merge_size, int(w) // merge_size, merge_size)
        for t, h, w in rows
    ]
    return idx_tensor, weight_tensor, split_sizes, shapes


@torch._dynamo.disable
def _lookup_pos_embed_tables(self, grid_thw: torch.Tensor, device, dtype):
    """Return the cached tables for ``grid_thw``, building them on first sight."""
    key = (tuple(grid_thw.detach().to("cpu").flatten().tolist()), str(device), str(dtype))
    cached = _POS_EMBED_CACHE.get(key)
    if cached is None:
        idx_tensor, weight_tensor, split_sizes, shapes = _build_pos_embed_tables(
            self, grid_thw, dtype
        )
        if len(_POS_EMBED_CACHE) >= _POS_EMBED_CACHE_LIMIT:
            _POS_EMBED_CACHE.clear()
        # ``.to(device)`` only moves storage; it never changes the values.
        cached = (idx_tensor.to(device), weight_tensor.to(device), split_sizes, shapes)
        _POS_EMBED_CACHE[key] = cached
    return cached


def fast_pos_embed_interpolate(self, grid_thw: torch.Tensor) -> torch.Tensor:
    """Cached, traceable replacement for the Qwen3-VL vision position embedding."""
    weight = self.pos_embed.weight
    idx_tensor, weight_tensor, split_sizes, shapes = _lookup_pos_embed_tables(
        self, grid_thw, weight.device, weight.dtype
    )

    pos_embeds = self.pos_embed(idx_tensor) * weight_tensor[:, :, None]
    patch_pos_embeds = pos_embeds[0] + pos_embeds[1] + pos_embeds[2] + pos_embeds[3]

    patch_pos_embeds = patch_pos_embeds.split(split_sizes)

    patch_pos_embeds_permute = []
    for pos_embed, (t, h, w, merge_size) in zip(patch_pos_embeds, shapes):
        pos_embed = pos_embed.repeat(t, 1)
        pos_embed = (
            pos_embed.view(t, h, merge_size, w, merge_size, -1)
            .permute(0, 1, 3, 2, 4, 5)
            .flatten(0, 4)
        )
        patch_pos_embeds_permute.append(pos_embed)
    return torch.cat(patch_pos_embeds_permute)
