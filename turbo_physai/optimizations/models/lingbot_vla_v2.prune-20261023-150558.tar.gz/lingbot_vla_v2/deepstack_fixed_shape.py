# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause
#
# Modified by Hygon: replace Qwen3-VL's boolean-mask scatter with a
# shape-stable ``masked_scatter`` so the deepstack branch survives Dynamo.
#
# Wrapped symbol and its TurboPhysAI replacement:
#   transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLTextModel.
#   _deepstack_process
#       -> this module's _deepstack_process
#
# Declared by the Group ``lingbot-vla-v2.deepstack-fixed-shape`` in catalog.py.
"""Make ``Qwen3VLTextModel._deepstack_process`` Dynamo-traceable.

Upstream implementation (``modeling_qwen3_vl.py``, ``_deepstack_process``)::

    visual_pos_masks = visual_pos_masks.to(hidden_states.device)
    visual_embeds = visual_embeds.to(hidden_states.device, hidden_states.dtype)
    local_this = hidden_states[visual_pos_masks, :].clone() + visual_embeds
    hidden_states[visual_pos_masks, :] = local_this
    return hidden_states

Both the read and the write are **boolean-mask advanced indexing**.  PyTorch
lowers that to ``aten.index`` + ``aten.nonzero``, whose output shape is
``mask.sum()`` -- a value only known once the data is on the device.  During
AOTAutograd's fake-tensor pass there is no data, so the shape stays an unbacked
symbol and the whole frame fails to compile::

    Backend compiler exception
      Explanation: Backend compiler `inductor` failed with aten.nonzero.default
    Dynamic shape operator
      Explanation: Operator `aten.nonzero.default`'s output shape depends on
                   input Tensor data.

In the DCU trace the failure shows up right here, and because the call sits
inside the decoder-layer loop Dynamo also hits ``maybe_has_backedge()`` and
drops the entire enclosing frame (``SkipFrame``).

The replacement keeps the same arithmetic but removes the data-dependent
shape: ``masked_scatter`` writes into a tensor shaped like ``input`` (a static
shape, known from ``hidden_states`` alone) and only the *source* length is
data-dependent, which is a runtime assertion rather than a shape constraint.
Fresh masks are allocated with ``zeros_like`` so untouched rows keep the exact
value they had: ``hidden + 0.0 == hidden`` for every dtype used here, so the
forward result is bit-identical (verified: max abs diff ``0.0``) and the
gradients match to the last bit as well.

Deliberately *not* changed: the model source.  The patch replaces the bound
method after ``transformers`` is imported, so the installed file stays
byte-identical and upstream hash checks keep working.
"""

from __future__ import annotations

import torch


def _deepstack_process(
    self,
    hidden_states: torch.Tensor,
    visual_pos_masks: torch.Tensor,
    visual_embeds: torch.Tensor,
) -> torch.Tensor:
    """``hidden_states[mask] += visual_embeds`` with a static output shape.

    The only shape Dynamo has to infer here is ``hidden_states``'s own, which
    comes from the graph inputs.  ``masked_scatter_``'s output shape is by
    definition the shape of the tensor being written, so no ``nonzero`` and no
    unbacked symbol ever enters the graph.
    """

    visual_pos_masks = visual_pos_masks.to(hidden_states.device)
    visual_embeds = visual_embeds.to(hidden_states.device, hidden_states.dtype)

    # ``unsqueeze(-1).expand_as`` is a zero-copy view: a bool mask of shape
    # ``[*frame_dims, 1]`` broadcast over the feature dim.  It keeps working
    # for the 2-D (``[seq, dim]``) and 3-D (``[batch, seq, dim]``) call shapes
    # that Qwen3-VL uses.
    scatter_mask = visual_pos_masks.unsqueeze(-1).expand_as(hidden_states)

    # Accumulate into a zero tensor instead of scattering in place: the mask
    # rows must be *added* to the existing activation, not overwritten.
    delta = torch.zeros_like(hidden_states)
    delta.masked_scatter_(scatter_mask, visual_embeds)
    return hidden_states + delta
