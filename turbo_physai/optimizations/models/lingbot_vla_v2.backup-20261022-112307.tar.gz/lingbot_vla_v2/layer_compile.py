# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause
#
# Modified by Hygon: compile the VLA transformer blocks one at a time.
#
# Wrapped symbols and their TurboPhysAI replacements:
#   lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla.Qwen3VLTextDecoderLayer.forward
#   lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla.Qwen3VLVisionBlock.forward
#   lingbotvla.models.vla.lingbot_vla.qwen2_action_expert.Qwen2DecoderLayer.forward
#       -> this module's compiled_block_forward wrapper
#
# Declared by the Group ``lingbot-vla-v2.compile`` in catalog.py.
"""Compile one transformer block at a time instead of the whole model.

Why compiling the whole model left the main model eager
------------------------------------------------------
``train_lingbotvla.py`` calls ``torch.compile(model)``, but every block
inherits ``transformers.GradientCheckpointingLayer``, whose ``__call__`` hands
``partial(super().__call__, **kwargs)`` to the activation checkpoint function.
Dynamo cannot introspect that partial, so the enclosing graph breaks at every
block boundary.  The profile shows the result: the LLM / action-expert compute
runs one ATen kernel at a time, tens of thousands of them per step.

What this wrapper compiles
--------------------------
The per-block ``forward`` instead of the model.  The checkpoint wrapper keeps
calling it eagerly, but that call now runs inside an Inductor graph, so the
RMSNorm / residual / activation / cast chains inside a block are fused.  This
is the boundary the block already had: the gradient-checkpoint recomputation
during backward compiles its own no-grad graph, and FSDP2's all-gather
(pre-forward hook) and reshard (post-forward hook) stay on ``__call__``,
outside the graph.

The compiled callable is created lazily on the first call of each block
instance and cached, so import and Group preparation stay side-effect free.
``options["compile"]`` is passed verbatim to ``torch.compile``; for the fixed
shapes this model sees every step that is e.g. ``{"dynamic": False}``.
"""

from __future__ import annotations

import functools
import threading
import weakref

import torch

_LOCK = threading.Lock()
# Per block instance -> its compiled forward; weak keys so sharded blocks can die.
_COMPILED: "weakref.WeakKeyDictionary[object, object]" = weakref.WeakKeyDictionary()


def compiled_block_forward(original, options=None):
    """Return a wrapper that compiles ``original`` per block instance."""

    compile_options = dict((options or {}).get("compile") or {})

    @functools.wraps(original)
    def wrapped(self, *args, **kwargs):
        compiled = _COMPILED.get(self)
        if compiled is None:
            with _LOCK:
                compiled = _COMPILED.get(self)
                if compiled is None:
                    compiled = torch.compile(original, **compile_options)
                    _COMPILED[self] = compiled
        return compiled(self, *args, **kwargs)

    return wrapped
