# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause
#
# Modified by Hygon: the Qwen3-VL patch projection is a Conv3d whose kernel window
# exactly covers its input, so it is a matrix product; MIOpen runs it with a naive
# implicit GEMM at 0.22 TFLOPS, and the weight gradient with a second one.
#
# Replaced symbol and its TurboPhysAI replacement:
#   transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLVisionPatchEmbed.forward
#       -> this module's forward
#
# Declared by the Group ``lingbot-vla-v2.vision-patch-embed`` in catalog.py.
"""Run the Qwen3-VL patch projection as the GEMM it already is.

The convolution
---------------
``Qwen3VLVisionPatchEmbed`` builds its projection with ``stride == kernel_size``
and no padding::

    kernel_size = [temporal_patch_size, patch_size, patch_size]   # [2, 16, 16]
    self.proj = nn.Conv3d(in_channels, embed_dim, kernel_size=kernel_size,
                          stride=kernel_size, bias=True)

``forward`` first views the flat image token stream as
``(N, in_channels, 2, 16, 16)`` -- one input block per kernel window -- so the
output is ``(N, embed_dim, 1, 1, 1)`` and is viewed back to ``(N, embed_dim)``.
No window overlaps, nothing is padded, no input is reused: the convolution is
exactly one matrix product

    (N, 1536) @ (1024, 1536)^T + bias        K = 3 * 2 * 16 * 16 = 1536

For the robotwin configuration (``N = 24576``) that is 77.3 GFLOP, and it is the
same 77.3 GFLOP whichever way it is spelled.

What it costs on HCU
--------------------
MIOpen exposes a single NCDHW bf16 forward solution for this geometry
(``miopenConvolutionForwardGetSolutionCount`` returns 1, for every find mode
including exhaustive), and it is an implicit GEMM that gives each thread three
multiply-accumulates: grid ``[256, 8, 24576]`` x block ``[256, 1, 1]``, 50.3
million blocks, 12.9 G threads.  In the two-step robotwin profile it costs
330.1 ms per step; standalone it measures 352 ms, i.e. 0.22 TFLOPS on a device
that runs the identical product as ``F.linear`` in 0.79 ms -- 98.5 TFLOPS, the
same arithmetic 445x faster.

The weight gradient is worse value still.  ``aten::convolution_backward`` spends
another 251.5 ms per step in ``conv3d_ncxdhw32_bf16_wrw_implicitgemm_...`` plus
four layout/workspace kernels that pad NCDHW into the kernel's NCXDHW32 layout.
The image batch never requires grad, so no grad-input kernel runs at all -- the
backward exists purely to produce the two gradients this module still has to
produce.

Stating the projection as ``F.linear`` removes all of it, because autograd then
differentiates a matrix product instead of a convolution: the forward is the
0.79 ms GEMM above and the weight gradient is a single ``mm`` of the same 77.3
GFLOP (the input-gradient branch is not taken, exactly as before).  Together the
two HCU convolution kernels and their four padding kernels account for roughly
586 ms of a step that takes 8.48 s.

The alternatives, and why not
-----------------------------
``torch.channels_last_3d`` unlocks MIOpen's far better NDHWC solution (22 ms),
and it is the right answer when the weights may be reformatted.  Here they may
not: a loaded checkpoint fixes the Conv3d weight layout, and the layout is not
preserved through ``torch.compile`` anyway -- Inductor converts the input back to
contiguous on entry to the compiled region and the 22 ms becomes 352 ms again.
It only holds up behind a ``@torch.compiler.disable``, which would also cut the
vision tower out of the compiled region.  ``F.linear`` needs neither the layout
conversion nor the compile barrier, and it is the faster of the two.

Weights are untouched
---------------------
``self.proj`` stays the very same ``nn.Conv3d``, so nothing about the module,
its ``state_dict`` or a checkpoint changes: the keys are still ``proj.weight``
and ``proj.bias``, the shapes are still ``(1024, 3, 2, 16, 16)`` and ``(1024,)``,
and ``load_state_dict`` needs no hooks and no permutation.  ``proj.weight`` is
merely read through a zero-copy ``view(embed_dim, -1)``, and the gradient that
flows back through that view lands in ``proj.weight.grad`` with the original
4-D shape, so a sharded (FSDP) parameter, its optimizer state and its
reduce-scatter are unaffected.  Only this ``forward`` changes, and it can be
reverted by reverting one Group.

Numerics
--------
The convolution and the matrix product accumulate in different orders.  In fp32
the two agree to a relative 2.3e-06, and the gradients to 2.4e-06 (``grad_bias``
bit-for-bit).  Both are well inside the run-to-run variation the rest of the
tower already produces, and against an fp64 reference a bf16 ``F.linear`` is in
fact slightly closer than a bf16 ``Conv3d`` (1.2e-02 vs 1.9e-02 max absolute
error), because the convolution's longer accumulation chain rounds more often.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F


def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
    """Upstream ``Qwen3VLVisionPatchEmbed.forward`` as a matrix product."""

    weight = self.proj.weight
    hidden_states = hidden_states.to(dtype=weight.dtype)
    hidden_states = hidden_states.view(
        -1, self.in_channels, self.temporal_patch_size, self.patch_size, self.patch_size
    )

    # stride == kernel_size with no padding, so every kernel window holds exactly
    # one input block: the convolution output is (N, embed_dim, 1, 1, 1), and each
    # output channel is one dot product over the C * T * H * W block.  Flattening
    # both operands in the same C, T, H, W order gives that dot product directly.
    hidden_states = hidden_states.reshape(hidden_states.shape[0], -1)
    weight = weight.reshape(weight.shape[0], -1)
    return F.linear(hidden_states, weight, self.proj.bias)
