# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause
#
# Modified by Hygon: checkpoint the VLA blocks with reentrant activation
# checkpointing so that a compiled block forward can live inside it.
#
# Wrapped symbol and its TurboPhysAI replacement:
#   transformers.modeling_layers.GradientCheckpointingLayer.__call__
#       (base of Qwen3VLTextDecoderLayer, Qwen3VLVisionBlock and Qwen2DecoderLayer)
#       -> this module's reentrant_block_call wrapper
#
# Declared by the Group ``lingbot-vla-v2.compile``.
"""Switch the block checkpoint from non-reentrant to reentrant.

Why the non-reentrant checkpoint blocks compilation
---------------------------------------------------
``GradientCheckpointingLayer.__call__`` hands ``partial(super().__call__)`` to
``torch.utils.checkpoint`` (non-reentrant).  That implementation keeps the
ordinary autograd graph and only replaces the saved tensors with placeholders,
so its backward is the AOTAutograd backward of the compiled block.  Compiling
the block inside it produces two different AOT graphs (the forward runs with
grad-enabled inputs, the recomputation with detached ones) that save the same
tensors in a different order, and the positional metadata check raises
``CheckpointError`` -- or worse, feeds the backward mismatched tensors.

What this wrapper changes
-------------------------
The block is checkpointed with ``use_reentrant=True`` instead.  A reentrant
checkpoint stores only the inputs and, in backward, re-runs the forward under
``autograd.grad``; it never relies on the saved-tensor layout of the compiled
graph, so a compiled block forward is safe inside it.  The checkpoint function
is ``nn.Module.__call__`` -- not ``self.forward`` -- so the module's own hooks,
FSDP2's included, still run inside the checkpointed region.

The forward pass therefore runs under ``no_grad`` and recomputation under
``enable_grad``, which makes Dynamo keep one graph per mode.  That is expected.

The training configuration normally selects the reentrant variant itself
(``enable_reentrant``), but its patched ``CheckpointFunction`` reads
``run_function.__self__``, which a ``functools.partial`` does not have.  This
wrapper bypasses that path and uses the stock ``torch.utils.checkpoint``.

FSDP2 note
----------
``torch.distributed.fsdp.fully_shard`` unshards parameters in a forward
pre-hook, and on the recompute path it relies on a pre-backward hook that
``_post_forward`` registers on the forward output.  That output belongs to the
no-grad first pass, which this checkpoint discards, so the hook never fires and
the recomputation reads resharded DTensor parameters.  The wrapper therefore
unshards explicitly on the recompute path, where grad mode is enabled.
"""

from __future__ import annotations

import functools
import warnings

import torch
from torch import nn


def _checkpoint(function, *args):
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*use_reentrant.*")
        return torch.utils.checkpoint.checkpoint(function, *args, use_reentrant=True)


def reentrant_block_call(original, options=None):
    """Return a ``GradientCheckpointingLayer.__call__`` that checkpoints reentrantly."""

    @functools.wraps(original)
    def wrapped(self, *args, **kwargs):
        if not (getattr(self, "gradient_checkpointing", False) and self.training):
            return original(self, *args, **kwargs)
        def _run(*inner):
            # nn.Module.__call__ keeps the module's hooks (FSDP2's among them)
            # inside the checkpointed region.
            #
            # FSDP2 only unshards in ``_pre_forward`` outside ``PRE_BACKWARD``.
            # On the recompute path it expects the pre-backward hook registered
            # by ``_post_forward`` to have done it, but that hook hangs off the
            # output of the no-grad first pass, which this checkpoint discards,
            # so it never fires and the recomputation would read the resharded
            # DTensor parameters (under ``torch.compile`` that surfaces as
            # ``aten.mul`` receiving a DTensor and a plain Tensor).  Grad mode
            # separates the two passes: the checkpoint forward runs under
            # ``no_grad`` and the recomputation under ``enable_grad``.
            if torch.is_grad_enabled():
                unshard = getattr(self, "unshard", None)
                if unshard is not None:
                    unshard()
            return nn.Module.__call__(self, *inner, **kwargs)

        return _checkpoint(_run, *args)

    return wrapped
