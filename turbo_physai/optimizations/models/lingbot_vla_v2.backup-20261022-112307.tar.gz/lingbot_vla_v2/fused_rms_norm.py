# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause
#
# Modified by Hygon: run the hand-written RMSNorm chains as one fused aten op.
#
# Wrapped symbols and their TurboPhysAI replacements:
#   transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLTextRMSNorm.forward
#       (text decoder layers and the final norm of the LLM)
#   lingbotvla.models.vla.lingbot_vla.qwen2_action_expert.FixQwen2RMSNorm.forward
#       (action-expert decoder layers)
#       -> this module's forward wrapper
#
# Declared by the Group ``lingbot-vla-v2.fused-rms-norm`` in catalog.py.
"""Replace the RMSNorm op chain with ``torch.nn.functional.rms_norm``.

Both write out the same eight elementwise steps by hand::

    x_fp32 = x.to(torch.float32)
    variance = x_fp32.pow(2).mean(-1, keepdim=True)
    x_norm = x_fp32 * torch.rsqrt(variance + eps)
    out = weight * x_norm.to(x.dtype)

Every step is a separate kernel with a full read/write of the activation, and
each block runs two of them, twice per step (forward plus the gradient
checkpoint recomputation).  ``F.rms_norm`` does the same arithmetic (fp32
accumulation, same eps placement) as a single fused kernel, so the chain
collapses to two kernels: the norm and the weight multiply.

The weight multiply stays a separate op on purpose: under FSDP2 the parameter
can be a DTensor, and keeping the same ``weight * x`` form preserves whatever
dispatch the original code relied on.  ``F.rms_norm`` therefore runs with
``weight=None``.

The replacement is safe under activation checkpointing: it is an ordinary
eager op, so the forward pass and the checkpoint recomputation save exactly the
same tensors in the same order.  Compiling the block instead would not be safe
-- see layer_compile.py for why.
"""

from __future__ import annotations

import functools

import torch
import torch.nn.functional as F


def forward(self, hidden_states):
    """RMSNorm as one fused kernel plus the weight multiply."""

    normalized = F.rms_norm(
        hidden_states,
        (hidden_states.shape[-1],),
        None,
        self.variance_epsilon,
    )
    weight = self.weight
    if weight.dtype != normalized.dtype:
        # Mixed-precision runs keep master weights in fp32; cast like the
        # original ``weight * x.to(input_dtype)`` did.
        weight = weight.to(normalized.dtype)
    return weight * normalized
