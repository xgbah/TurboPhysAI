# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause
#
# Modified by Hygon: the Qwen3-VL vision tower walks ``grid_thw`` on the device.
#
# Replaced symbols and their TurboPhysAI replacements:
#   transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLVisionModel.rot_pos_emb
#       -> this module's rot_pos_emb
#   transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLVisionModel.
#   fast_pos_embed_interpolate
#       -> this module's fast_pos_embed_interpolate
#
# Declared by the Group ``lingbot-vla-v2.vision-grid-thw`` in catalog.py.

from __future__ import annotations

import torch


def rot_pos_emb(self, grid_thw: torch.Tensor) -> torch.Tensor:
    """Upstream ``Qwen3VLVisionModel.rot_pos_emb`` with a host-side loop."""

    merge_size = self.spatial_merge_size
    grid = grid_thw.tolist()

    max_hw = max(max(h, w) for _, h, w in grid)
    freq_table = self.rotary_pos_emb(max_hw)
    device = freq_table.device

    total_tokens = sum(t * h * w for t, h, w in grid)
    pos_ids = torch.empty((total_tokens, 2), dtype=torch.long, device=device)

    intra_row = torch.arange(merge_size, device=device)  # intra-block row offsets
    intra_col = torch.arange(merge_size, device=device)  # intra-block col offsets

    offset = 0
    for num_frames, height, width in grid:
        merged_h, merged_w = height // merge_size, width // merge_size

        block_rows = torch.arange(merged_h, device=device)  # block row indices
        block_cols = torch.arange(merged_w, device=device)  # block col indices

        row_idx = block_rows[:, None, None, None] * merge_size + intra_row[None, None, :, None]
        col_idx = block_cols[None, :, None, None] * merge_size + intra_col[None, None, None, :]

        row_idx = row_idx.expand(merged_h, merged_w, merge_size, merge_size).reshape(-1)
        col_idx = col_idx.expand(merged_h, merged_w, merge_size, merge_size).reshape(-1)

        coords = torch.stack((row_idx, col_idx), dim=-1)

        if num_frames > 1:
            coords = coords.repeat(num_frames, 1)

        num_tokens = coords.shape[0]
        pos_ids[offset : offset + num_tokens] = coords
        offset += num_tokens

    embeddings = freq_table[pos_ids]  # lookup rotary embeddings
    return embeddings.flatten(1)


def fast_pos_embed_interpolate(self, grid_thw):
    """Upstream ``Qwen3VLVisionModel.fast_pos_embed_interpolate``, same fix."""

    grid = grid_thw.tolist()

    idx_list = [[] for _ in range(4)]
    weight_list = [[] for _ in range(4)]

    for t, h, w in grid:
        h_idxs = torch.linspace(0, self.num_grid_per_side - 1, h)
        w_idxs = torch.linspace(0, self.num_grid_per_side - 1, w)

        h_idxs_floor = h_idxs.int()
        w_idxs_floor = w_idxs.int()
        h_idxs_ceil = (h_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)
        w_idxs_ceil = (w_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)

        dh = h_idxs - h_idxs_floor
        dw = w_idxs - w_idxs_floor

        base_h = h_idxs_floor * self.num_grid_per_side
        base_h_ceil = h_idxs_ceil * self.num_grid_per_side

        indices = [
            (base_h[None].T + w_idxs_floor[None]).flatten(),
            (base_h[None].T + w_idxs_ceil[None]).flatten(),
            (base_h_ceil[None].T + w_idxs_floor[None]).flatten(),
            (base_h_ceil[None].T + w_idxs_ceil[None]).flatten(),
        ]

        weights = [
            ((1 - dh)[None].T * (1 - dw)[None]).flatten(),
            ((1 - dh)[None].T * dw[None]).flatten(),
            (dh[None].T * (1 - dw)[None]).flatten(),
            (dh[None].T * dw[None]).flatten(),
        ]

        for i in range(4):
            idx_list[i].extend(indices[i].tolist())
            weight_list[i].extend(weights[i].tolist())

    idx_tensor = torch.tensor(idx_list, dtype=torch.long, device=self.pos_embed.weight.device)
    weight_tensor = torch.tensor(
        weight_list, dtype=self.pos_embed.weight.dtype, device=self.pos_embed.weight.device
    )
    pos_embeds = self.pos_embed(idx_tensor) * weight_tensor[:, :, None]
    patch_pos_embeds = pos_embeds[0] + pos_embeds[1] + pos_embeds[2] + pos_embeds[3]

    patch_pos_embeds = patch_pos_embeds.split([h * w for _, h, w in grid])

    patch_pos_embeds_permute = []
    merge_size = self.config.spatial_merge_size
    for pos_embed, (t, h, w) in zip(patch_pos_embeds, grid):
        pos_embed = pos_embed.repeat(t, 1)
        pos_embed = (
            pos_embed.view(t, h // merge_size, merge_size, w // merge_size, merge_size, -1)
            .permute(0, 1, 3, 2, 4, 5)
            .flatten(0, 4)
        )
        patch_pos_embeds_permute.append(pos_embed)
    patch_pos_embeds = torch.cat(patch_pos_embeds_permute)
    return patch_pos_embeds
