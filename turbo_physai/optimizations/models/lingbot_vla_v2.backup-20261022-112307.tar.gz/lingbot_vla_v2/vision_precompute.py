# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause
#
# Modified by Hygon: the Qwen3-VL vision tower recomputes its precomputed
# grid_thw tensors on every forward, because the guard below tests more than the
# cache can ever satisfy.
#
# Replaced symbol and its TurboPhysAI replacement:
#   lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla.forward_without_grid_thw
#       -> this module's forward_without_grid_thw
#
# Declared by the Group ``lingbot-vla-v2.vision-precompute`` in catalog.py.
"""Honour the ``precompute_grid_thw`` cache in the Qwen3-VL vision tower.

The dead cache
--------------
With ``precompute_grid_thw: true`` (the robotwin HCU config), the model computes
the grid-shaped tensors once and caches them on itself
(``modeling_lingbot_vla_v2.py``)::

    if precompute_grid_thw and self.position_embeddings is None:
        (self.pos_embeds, self.position_embeddings, self.cu_seqlens,
         self.visual_split_sizes, self.visual_max_seqlen) = \
            self.qwenvl.visual.preprcess_grid_thw(grid_thw=image_grid_thw)

``preprcess_grid_thw`` returns ``None`` as its first value on purpose:
``pos_embeds`` comes from ``fast_pos_embed_interpolate`` and therefore from the
trainable ``pos_embed`` embedding, so it must not be cached across steps -- it is
recomputed from ``grid_thw`` below.  ``self.pos_embeds`` is consequently always
``None``.

The guard that reads the cache also tests that always-``None`` value::

    if pos_embeds is None or position_embeddings is None or cu_seqlens is None or max_seqlen is None:
        pos_embeds, position_embeddings, cu_seqlens, _, max_seqlen = self.preprcess_grid_thw(grid_thw)

It is true on every forward, so the whole precomputation -- ``rot_pos_emb``
included -- runs again each step and its result overwrites the tensors just read
from the cache.  The cache never takes effect: a two-step profile shows
``rot_pos_emb`` called twice (once per step) instead of never.

What is changed
---------------
``pos_embeds is None`` is dropped from the recompute test, and the three
grid-shaped tensors are taken from the caller.  ``pos_embeds`` is still
recomputed whenever it is ``None``, so the trainable embedding keeps receiving
its gradient, and ``preprcess_grid_thw`` now runs once per process instead of
once per forward (``grid_thw`` is no longer needed for that call).

Nothing changes while ``precompute_grid_thw`` is false: the cache is never
populated, every argument arrives as ``None``, and this function then computes
exactly what the repository version computed.
"""

from __future__ import annotations

from typing import Optional

import torch


def forward_without_grid_thw(
    self,
    hidden_states: torch.Tensor,
    grid_thw: torch.Tensor = None,
    pos_embeds: Optional[torch.Tensor] = None,
    position_embeddings: Optional[tuple[torch.Tensor, torch.Tensor]] = None,
    cu_seqlens: Optional[torch.Tensor] = None,
    max_seqlen: Optional[int] = None,
    **kwargs,
) -> torch.Tensor:
    hidden_states = self.patch_embed(hidden_states)

    if position_embeddings is None or cu_seqlens is None or max_seqlen is None:
        _, position_embeddings, cu_seqlens, _, max_seqlen = self.preprcess_grid_thw(grid_thw)
    if pos_embeds is None:
        pos_embeds = self.fast_pos_embed_interpolate(grid_thw)

    hidden_states = hidden_states + pos_embeds
    seq_len, _ = hidden_states.size()
    hidden_states = hidden_states.reshape(seq_len, -1)

    deepstack_feature_lists = []
    for layer_num, blk in enumerate(self.blocks):
        hidden_states = blk(
            hidden_states,
            cu_seqlens=cu_seqlens,
            position_embeddings=position_embeddings,
            max_seqlen=max_seqlen,
            **kwargs,
        )
        if layer_num in self.deepstack_visual_indexes:
            deepstack_feature = self.deepstack_merger_list[self.deepstack_visual_indexes.index(layer_num)](
                hidden_states
            )
            deepstack_feature_lists.append(deepstack_feature)

    hidden_states = self.merger(hidden_states)
    return hidden_states, deepstack_feature_lists
