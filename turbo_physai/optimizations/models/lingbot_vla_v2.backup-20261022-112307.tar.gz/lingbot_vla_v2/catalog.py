# Copyright 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: BSD-3-Clause

"""lingbot_vla_v2 optimization declarations.

Add model-specific Groups here. Importing this module registers the declarations
with TurboPhysAI; the generated OptimizationConfig loads it through optimization_modules.

Declarations only describe target/replacement pairs as strings; nothing here imports
lingbotvla and nothing resolves runtime objects at import time.

The package directory name must stay a valid Python identifier (``lingbot_vla_v2``),
because ``optimization_modules`` and every ``replacement`` path is imported through
``importlib``.  ``--model`` also normalizes ``-`` to ``_``, so a directory named
``lingbot_vla_v2`` is reachable as both ``--model lingbot-vla-v2`` and
``--model lingbot_vla_v2``, while a hyphenated directory name would be unreachable.
"""

from __future__ import annotations

from ....engine.definitions import group, replace, wrap

# --- Profiling: torch profiler setup -----------------------------------------
PROFILER = group(
    "lingbot-vla-v2.profiling",
    replace(
        target="lingbotvla.utils.helper.create_profiler",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.profiling.create_profiler"
        ),
    ),
)

# --- Muon optimizer: DTensor-aware Newton-Schulz orthogonalization -------------
MUON = group(
    "lingbot-vla-v2.muon",
    replace(
        target="lingbotvla.optim.muon.DistributedMuon",
        aliases=("lingbotvla.optim.optimizer.DistributedMuon",),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.muon.DistributedMuon"
        ),
    ),
    replace(
        target="lingbotvla.optim.muon.split_muon_adamw_params",
        aliases=("lingbotvla.optim.optimizer.split_muon_adamw_params",),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.muon.split_muon_adamw_params"
        ),
    ),
    replace(
        target="lingbotvla.optim.muon.batched_newton_schulz",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.muon.batched_newton_schulz"
        ),
    ),
)

# --- Attention: tuned flex-attention kernel-option table ----------------------
FLEX_KERNEL_OPTIONS = group(
    "lingbot-vla-v2.flex-kernel-options",
    wrap(
        target="lingbotvla.models.vla.lingbot_vla.flex_attention.flex_attention",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.flex_kernel_options."
            "flex_attention_kernel_options"
        ),
    ),
)

# --- Vision tower: grid_thw loop variables as python ints ---------------------
VISION_GRID_THW = group(
    "lingbot-vla-v2.vision-grid-thw",
    replace(
        target=(
            "transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLVisionModel."
            "rot_pos_emb"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.vision_grid_thw."
            "rot_pos_emb"
        ),
    ),
    replace(
        target=(
            "transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLVisionModel."
            "fast_pos_embed_interpolate"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.vision_grid_thw."
            "fast_pos_embed_interpolate"
        ),
    ),
)

# --- Vision tower: patch embedding as a GEMM instead of a Conv3d --------------
VISION_PATCH_EMBED = group(
    "lingbot-vla-v2.vision-patch-embed",
    replace(
        target=(
            "transformers.models.qwen3_vl.modeling_qwen3_vl.Qwen3VLVisionPatchEmbed."
            "forward"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.vision_patch_embed."
            "forward"
        ),
    ),
)

# --- Vision tower: make the precompute_grid_thw cache take effect -------------
VISION_PRECOMPUTE = group(
    "lingbot-vla-v2.vision-precompute",
    replace(
        target=(
            "lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla."
            "forward_without_grid_thw"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.vision_precompute."
            "forward_without_grid_thw"
        ),
    ),
)

# --- Compilation: one compiled graph per block, and per teacher --------------
# Three pieces that only make sense together:
#   * reentrant checkpointing: the non-reentrant variant compares the tensors
#     saved by the forward against the ones saved by the recomputation, and two
#     AOTAutograd graphs never agree on that order, so a compiled block may only
#     live inside a reentrant checkpoint;
#   * block-level torch.compile: compiling the whole model breaks at every
#     GradientCheckpointingLayer boundary (its __call__ hands a partial to the
#     checkpoint function);
#   * the frozen distillation teachers, which the training loop reaches through
#     .infer() / .infer_feat() / adapter.get_intermediate_layers() -- paths that
#     torch.compile(moge_model) never touched.
COMPILE = group(
    "lingbot-vla-v2.compile",
    wrap(
        target="transformers.modeling_layers.GradientCheckpointingLayer.__call__",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2."
            "reentrant_checkpoint.reentrant_block_call"
        ),
    ),
    wrap(
        target=(
            "lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla."
            "Qwen3VLTextDecoderLayer.forward"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.layer_compile."
            "compiled_block_forward"
        ),
    ),
    wrap(
        target=(
            "lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla."
            "Qwen3VLVisionBlock.forward"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.layer_compile."
            "compiled_block_forward"
        ),
    ),
    wrap(
        target=(
            "lingbotvla.models.vla.lingbot_vla.qwen2_action_expert."
            "Qwen2DecoderLayer.forward"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.layer_compile."
            "compiled_block_forward"
        ),
    ),
    wrap(
        target="lingbotvla.models.vla.vision_models.module_utils.v2.forward",
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2."
            "teacher_forward_compile.compiled_forward"
        ),
    ),
    wrap(
        target=(
            "lingbotvla.models.vla.vision_models.module_utils."
            "v2_morgbd.forward_feat"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2."
            "teacher_forward_compile.compiled_forward"
        ),
    ),
    wrap(
        target=(
            "lingbotvla.models.vla.vision_models.dino_video.lumos_dinov3."
            "models.inference.CausalEvalAdapter.get_intermediate_layers"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2."
            "teacher_forward_compile.compiled_forward"
        ),
    ),
)

# --- Norms: hand-written RMSNorm chain as one fused aten op ------------------
# Both RMSNorm variants expand to eight elementwise kernels per call
# (cast / pow / mean / add / rsqrt / mul / cast / mul) over the full activation.
# F.rms_norm computes the same arithmetic in one fused kernel, which matters
# because every decoder block runs two of them, twice per step once the
# gradient-checkpoint recomputation is counted.  Stays eager on purpose: an
# ordinary op keeps the checkpoint's saved tensors in the same order.
FUSED_RMS_NORM = group(
    "lingbot-vla-v2.fused-rms-norm",
    replace(
        target=(
            "transformers.models.qwen3_vl.modeling_qwen3_vl."
            "Qwen3VLTextRMSNorm.forward"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.fused_rms_norm.forward"
        ),
    ),
    replace(
        target=(
            "lingbotvla.models.vla.lingbot_vla.qwen2_action_expert."
            "FixQwen2RMSNorm.forward"
        ),
        replacement=(
            "turbo_physai.optimizations.models.lingbot_vla_v2.fused_rms_norm.forward"
        ),
    ),
)
